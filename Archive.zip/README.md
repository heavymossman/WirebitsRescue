# WirebitsConsole
Wirebits is an ERC20 Token to be used on the Bywire.news platform

Dependencies so far: 
pragma solidity ^0.4.23;
Truffle
chocolatey
nodejs
production windows-build-tools
ethereumjs-testrpc
Ganache 
